import container

def main(args):
    return container.evaluate("", "text.txt", "Test")
