import container

def main():
    return container.evaluate("", "text.txt", "Test")

